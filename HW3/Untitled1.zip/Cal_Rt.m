function [ P_hat,Phat_num ] = Cal_Rt( Inhom_Points3D_3,HatInhom_Point3D_3 )
%CAL_RT Summary of this function goes here
%   Detailed explanation goes here
P_hat = [];
counter = size(HatInhom_Point3D_3,2) / 3;
for i = 1 : counter
    x = Inhom_Points3D_3;
    y = HatInhom_Point3D_3(:,1+(i-1)*3 : 3+(i-1)*3);
    mu_x = mean(Inhom_Points3D_3,2);
    mu_y = mean(HatInhom_Point3D_3(:,1+(i-1)*3 : 3+(i-1)*3),2);
    Sigma = zeros(size(x,2));
    for i  = 1 : size(x,2)
        Sigma = Sigma + (y(:,i)-mu_y)*(x(:,i)-mu_x)';
    end
    Sigma = Sigma / 3;
    [U,D,V] = svd(Sigma);
    if rank(Sigma) >= size(x,1) - 1
        if det(Sigma) >= 0
            S = eye(3);
        else
            S = [1 0 0;0 1 0; 0 0 -1];
        end
        R = U * S * V';
        varx = sum(var(x,1,2)); 
        c = trace(D*S)/varx;
        t = mu_y - c * R * mu_x;
        P_hat = [P_hat;[R,t]];
    end       
end
Phat_num = size(P_hat,1) / 3;
end

