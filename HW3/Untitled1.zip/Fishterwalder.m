function [ P_Cam_3,UV_num ] = Fishterwalder( HatInhom_Point2D_3, Inhom_Points3D_3 )
% define p and q to calculate a, b, c, j, and angles

p1 = Inhom_Points3D_3(:,1);
p2 = Inhom_Points3D_3(:,2);
p3 = Inhom_Points3D_3(:,3);

f = 1;

q1 = HatInhom_Point2D_3(:,1)*f;
q2 = HatInhom_Point2D_3(:,2)*f;
q3 = HatInhom_Point2D_3(:,3)*f;

a = sqrt(sum((p2 - p3).^2));
b = sqrt(sum((p1 - p3).^2));
c = sqrt(sum((p1 - p2).^2));

j1 = [q1;1];
j2 = [q2;1];
j3 = [q3;1];
j1 = j1 / norm(j1,2);
j2 = j2 / norm(j2,2);
j3 = j3 / norm(j3,2);

alpha = acos(j2'*j3);
beta = acos(j1'*j3);
gamma = acos(j2'*j1);

G = c^2*(c^2*sin(beta)^2-b^2*sin(gamma)^2);
H = b^2*(b^2-a^2)*sin(gamma)^2+c^2*(c^2+2*a^2)*sin(beta)^2+2*b^2*c^2*(-1+cos(alpha)*cos(beta)*cos(gamma));
I = b^2*(b^2-c^2)*sin(alpha)^2+a^2*(a^2+2*c^2)*sin(beta)^2+2*a^2*b^2*(-1+cos(alpha)*cos(beta)*cos(gamma));
J = a^2*(a^2*sin(beta)^2-b^2*sin(alpha)^2);

lambda0 = 0;
lambda = roots([G H I J]);
for i = 1 : size(lambda,1)
    if isreal(lambda(i,1))
        lambda0 = lambda(i,1);
        break;
    end
end

A= 1+lambda0;
B = -cos(alpha);
C = (b^2-a^2)/b^2 - lambda0*c^2/b^2;
D = -lambda0*cos(gamma);
E = (a^2/b^2+lambda0*c^2/b^2)*cos(beta);
F = -a^2/b^2 + lambda0*(b^2-c^2)/b^2;

p = sqrt(B^2-A*C);
q = sign(B*E-C*D)*sqrt(E^2-C*F);
m1 = (-B+p)/C;
n1 = -(E-q)/C;
m2 = (-B-p)/C;
n2 = -(E+q)/C;

uv = Cal_uv( b,c,beta,gamma,m1,n1);
uv = [uv;Cal_uv( b,c,beta,gamma,m2,n2)];
P_Cam_3 = [];
if size(uv,1) ~= 0  
    for i = 1 : size(uv,1)
        s = Cal_s( a,uv(i,1),uv(i,2),alpha );
        P_Cam_3 = [P_Cam_3,ones(3,1)*s.*[j1,j2,j3]];
    end
end
UV_num = size(uv,1);
end

