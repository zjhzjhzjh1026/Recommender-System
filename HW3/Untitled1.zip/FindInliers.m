function [ Inhom_Points2D_Inliers, Inhom_Points3D_Inliers ] = FindInliers( P_hat, K, Hom_Points3D, Hom_Points2D,Tolerance, Inhom_Points2D, Inhom_Points3D )
%FINDINLIERS Summary of this function goes here
%   Detailed explanation goes here
P = K * P_hat;
Hom_2D_Estimate = P * Hom_Points3D;
InHom_2D_Estimate = Hom_2D_Estimate(1:2,:) ./ (ones(2,1) * Hom_2D_Estimate(3,:));
InHom_2D = Hom_Points2D(1:2,:) ./ (ones(2,1) * Hom_Points2D(3,:));
Error = InHom_2D_Estimate - InHom_2D;
Inhom_Points2D_Inliers = [];
Inhom_Points3D_Inliers = [];
for i = 1 : size(Error,2)
    en = norm(Error(:,i),2);
    if en < Tolerance
        Inhom_Points2D_Inliers = [Inhom_Points2D_Inliers; Inhom_Points2D(i,:)];
        Inhom_Points3D_Inliers = [Inhom_Points3D_Inliers; Inhom_Points3D(i,:)];
    end
end
Inhom_Points2D_Inliers = Inhom_Points2D_Inliers';
Inhom_Points3D_Inliers = Inhom_Points3D_Inliers';
end

