function [ s ] = Cal_s( a,u,v,alpha )
%CAL.S Summary of this function goes here
%   Detailed explanation goes here
s1 = sqrt(a^2/(u^2 + v^2 - 2*u*v*cos(alpha)));
s2 = u*s1;
s3 = v*s1;
s = [s1,s2,s3];
end

