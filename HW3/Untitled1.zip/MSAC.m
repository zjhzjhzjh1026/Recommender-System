function [ Best_cost,Best_Phat, maxinliner, maxTrails,Tolerance] = MSAC( HatInhom_Point2D,Inhom_Points3D,Hom_Points3D,Hom_Points2D,K,Tolerance)
%MSAC Summary of this function goes here
%   Detailed explanation goes here
Best_Phat = zeros(3,4);
Best_cost = Inf;
counter = 0;
maxTrails = Inf;
trails = 1;
while(trails < maxTrails)
%     RAN = randperm(60);
    RAN = [1,2,3];
    HatInhom_Point2D_3 = [HatInhom_Point2D(:,RAN(1,1)),HatInhom_Point2D(:,RAN(1,2)),HatInhom_Point2D(:,RAN(1,3))];
    Inhom_Points3D_3 = [Inhom_Points3D(RAN(1,1),:);Inhom_Points3D(RAN(1,2),:);Inhom_Points3D(RAN(1,3),:)]';
    [HatInhom_Point3D_3, UV_num] = Fishterwalder( HatInhom_Point2D_3, Inhom_Points3D_3);
    [P_hat,Phat_num]  = Cal_Rt( Inhom_Points3D_3,HatInhom_Point3D_3 );
    if Phat_num ~= 0
        counter = counter + Phat_num;
        for j = 1 : Phat_num
            [cost, inlier] = Cal_ErrorCost( P_hat(3*j-2:3*j,:), K, Hom_Points3D, Hom_Points2D,Tolerance);
            if(cost < Best_cost)
                Best_cost = cost;
                Best_Phat =  P_hat(3*j-2:3*j,:);
                maxinliner = inlier;
                maxTrails = log(1-0.99)/log(1-(maxinliner/60)^3);
            end
        end
    end
    trails = trails + 1;
end
end

