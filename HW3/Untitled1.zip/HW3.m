clear;clc;close all;
%% Outliers Rejection
Inhom_Points3D = importdata('hw3_points3D.txt');
Inhom_Points2D = importdata('hw3_points2D.txt');
K = [1545.0966799187809 0 639.5;
    0 1545.0966799187809 359.5;
    0 0 1];
Hom_Points3D = [Inhom_Points3D'; ones(1,size(Inhom_Points3D,1))];
Hom_Points2D = [Inhom_Points2D'; ones(1,size(Inhom_Points2D,1))];
HatHom_Point2D = inv(K) * Hom_Points2D;
HatInhom_Point2D = HatHom_Point2D(1:2,:) ./ (ones(2,1) * ...
    HatHom_Point2D(3,:));

alpha = 0.95;
codimension = 2; 
varMeanErr = 1;
Tolerance = chi2inv(alpha,codimension)*varMeanErr;
% MSAC
[ Best_cost,Best_Phat, maxinliner, maxTrails ,Tolerance] = MSAC(...
    HatInhom_Point2D,Inhom_Points3D,Hom_Points3D,Hom_Points2D,K,Tolerance);
% Find all inliers
[Inhom_Points2D_Inliers, Inhom_Points3D_Inliers ] = FindInliers(Best_Phat, ...
    K, Hom_Points3D, Hom_Points2D,Tolerance, Inhom_Points2D, Inhom_Points3D );

%% Linear Estimation
Hom_Points3D_Inliers = [Inhom_Points3D_Inliers; ones(1,size(Inhom_Points3D_Inliers,2))];
Hom_Points2D_Inliers = [Inhom_Points2D_Inliers; ones(1,size(Inhom_Points2D_Inliers,2))];
HatHom_Point2D_Inliers = inv(K) * Hom_Points2D_Inliers;
HatInhom_Point2D_Inliers = HatHom_Point2D_Inliers(1:2,:) ./(ones(2,1) * HatHom_Point2D_Inliers(3,:));
mu_Inhom3D_Inliers = mean(Inhom_Points3D_Inliers,2);
Sigma_Inhom3D_Inliers_Image = bsxfun(@minus,Inhom_Points3D_Inliers,mu_Inhom3D_Inliers)...
    *bsxfun(@minus,Inhom_Points3D_Inliers,mu_Inhom3D_Inliers)'/(maxinliner-1);
[U,D,V] = svd(Sigma_Inhom3D_Inliers_Image);
% Control Points
var_Inhom3D_Inliers_Image = trace(Sigma_Inhom3D_Inliers_Image);
s = sqrt(var_Inhom3D_Inliers_Image/3);
C1 = mu_Inhom3D_Inliers;
C2 = s * V(:,1) + C1;
C3 = s * V(:,2) + C1;
C4 = s * V(:,3) + C1;
Control_Image = [C1,C2,C3,C4];
Para_Matrix = inv([C2-C1,C3-C1,C4-C1]) * (Inhom_Points3D_Inliers - C1 * ones(1,maxinliner));
Para_Matrix = [ones(1,maxinliner) - sum(Para_Matrix);Para_Matrix];
Para_Inhom3D_Inliers_Image = Control_Image * Para_Matrix;
M = [];
for i = 1 : maxinliner
    m = [Para_Matrix(1,i) 0 -Para_Matrix(1,i)*HatInhom_Point2D_Inliers(1,i)...
         Para_Matrix(2,i) 0 -Para_Matrix(2,i)*HatInhom_Point2D_Inliers(1,i)...
         Para_Matrix(3,i) 0 -Para_Matrix(3,i)*HatInhom_Point2D_Inliers(1,i)...
         Para_Matrix(4,i) 0 -Para_Matrix(4,i)*HatInhom_Point2D_Inliers(1,i);...
         0 Para_Matrix(1,i) -Para_Matrix(1,i)*HatInhom_Point2D_Inliers(2,i)...
         0 Para_Matrix(2,i) -Para_Matrix(2,i)*HatInhom_Point2D_Inliers(2,i)...
         0 Para_Matrix(3,i) -Para_Matrix(3,i)*HatInhom_Point2D_Inliers(2,i)...
         0 Para_Matrix(4,i) -Para_Matrix(4,i)*HatInhom_Point2D_Inliers(2,i)];
     M = [M;m];
end
[U,S,V] = svd(M);
Control_Cam_Vec = V(:,size(V,2));
Control_Cam = reshape(Control_Cam_Vec,[3,4]);
Para_Inhom3D_Inliers_Cam = Control_Cam * Para_Matrix; 
mu_Para_Inhom3D_Inliers_Cam = mean(Para_Inhom3D_Inliers_Cam,2);
Sigma_Inhom3D_Inliers_Cam = bsxfun(@minus,Para_Inhom3D_Inliers_Cam,mu_Para_Inhom3D_Inliers_Cam)...
    *bsxfun(@minus,Para_Inhom3D_Inliers_Cam,mu_Para_Inhom3D_Inliers_Cam)'/(maxinliner-1);
var_Inhom3D_Inliers_Cam = trace(Sigma_Inhom3D_Inliers_Cam);
if mu_Para_Inhom3D_Inliers_Cam(3,1) < 0
    beta = -sqrt(var_Inhom3D_Inliers_Image/var_Inhom3D_Inliers_Cam);
else
    beta = sqrt(var_Inhom3D_Inliers_Image/var_Inhom3D_Inliers_Cam);   
end
Para_Inhom3D_Inliers_Cam = Para_Inhom3D_Inliers_Cam * beta;
