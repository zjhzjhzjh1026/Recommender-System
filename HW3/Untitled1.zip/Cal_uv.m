function [ uv ] = Cal_uv( b,c,beta,gamma,m,n )
%CAL_UV Summary of this function goes here
%   Detailed explanation goes here
uv = [];
A = b^2 - m^2 * c^2;
B = c^2*(cos(beta)-n)*m - b^2*cos(gamma);
C = -c^2*n^2+2*c^2*n*cos(beta)+b^2-c^2;
u_large = -sign(B)/A*(abs(B)+sqrt(B^2-A*C));
u_small = C/(A*u_large);
v_large = u_large*m+n;
v_small = u_small*m+n;
if isreal(u_large)
    uv = [uv;[u_large,v_large]];
end
if isreal(u_small)
    uv = [uv;[u_small,v_small]];
end
end

